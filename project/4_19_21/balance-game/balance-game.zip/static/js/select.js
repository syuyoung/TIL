// const select = document.querySelector('#post-detail button')

// select.addEventListener('clicked', () => {
//   console.log(select)
// })

// // function selectOption() {
// //   // 선택한 요소에 대한 ID를 가져옵니다.
// //   const selectedOption = document.getElementById("select");

// //   // 선택한 요소에 대해 클래스를 추가합니다.
// //   selectedOption.classList.add('selected');

// //   // 선택한 요소에 대한 애니메이션 효과를 정의합니다.
// //   const animation = selectedOption.animate(
// //     [
// //       { transform: 'scale(1)' },
// //       { transform: 'scale(1.1)' },
// //       { transform: 'scale(1)' }
// //     ],
// //     {
// //       duration: 1000,
// //       easing: 'ease-in-out'
// //     }
// //   );

// //   // 애니메이션이 완료된 후 클래스를 제거합니다.
// //   animation.onfinish = function() {
    
// //   };
// // }